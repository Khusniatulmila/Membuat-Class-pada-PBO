/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package membuatclass;

/**
 *
 * @author ASUS
 */
public class Utama {

    public static void main(String[] args) {
        Biodata biodata = new Biodata();
        
        biodata.infoNama();
        biodata.infojenisKelamin();
        biodata.infoTTL();
        biodata.infoUmur();
        biodata.infoAlamat();
        biodata.infoHobi();
        biodata.infoSekolah();
        biodata.infoJurusan();
        biodata.infoKelas();
        biodata.infoAbsen();
    }
    
}
