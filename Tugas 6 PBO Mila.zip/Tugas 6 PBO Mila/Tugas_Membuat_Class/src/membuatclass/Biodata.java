/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package membuatclass;

/**
 *
 * @author ASUS
 */
public class Biodata {
    public void infoNama() {
        System.out.println("Nama : Khusniatul Mila");
    }
    public void infojenisKelamin() {
        System.out.println("Jenis Kelamin : Perempuan");
    }
    public void infoTTL() {
        System.out.println("TTL : Pasuruan, 09 Januari 2004");
    }
    public void infoUmur() {
        System.out.println("Umur : 16 Tahun");
    }
    public void infoAlamat() {
        System.out.println("Alamat : Kr.Menggah, Wonorejo");
        }
    public void infoHobi() {
        System.out.println("Hobi : Menyanyi");
    }
    public void infoSekolah() {
        System.out.println("Sekolah : SMKN 1 Purwosari");
    }
    public void infoJurusan() {
        System.out.println("Jurusan : Rekayasa Perangkat Lunak");
    }
    public void infoKelas() {
        System.out.println("Kelas : XI-RPL 1");
    }
    public void infoAbsen() {
        System.out.println("No.Absen : 15");
    }
        
}